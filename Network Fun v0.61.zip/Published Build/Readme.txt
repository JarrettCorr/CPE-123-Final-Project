Networks-fun!
By: (Define TEAM "Awesome")

File Decriptions: 
-Networks-and-Run.rkt: 
Houses all the function involving signal-play and networks. It also makes the call to big-bang to begin the program. Requires Structs-Help-Setup.rkt, Events-and-Draw.rkt

-Events-and-Draw.rkt: 
Contains all the funtions necessary for big-bang. Requires Structs-Help-Setup.rkt

-Structs-Help-Setup.rkt:
Defines all structures, sets up useful global constants, and defines helpful functions that involve the structs defined.